package Modeloo;

/*** @author Licoreria
 */
public class Venta {
    
}
