package Modeloo;

/*** @author Licoreria
 */
public class Proveedor {
    private int Codigo_Proveedor;
    private String Nombre;
    private String Apellido;
    private String Telefono;
    private String Empresa;
    private String Direccion;

    public Proveedor(int Codigo_Proveedor, String Nombre, String Apellido, 
            String Telefono, String Empresa, String Direccion) {
        this.Codigo_Proveedor = Codigo_Proveedor;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Telefono = Telefono;
        this.Empresa = Empresa;
        this.Direccion = Direccion;
    }

    public Proveedor(String Nombre, String Apellido, String Telefono, 
            String Empresa, String Direccion) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Telefono = Telefono;
        this.Empresa = Empresa;
        this.Direccion = Direccion;
    }

    public int getCodigo_Proveedor() {
        return Codigo_Proveedor;
    }

    public void setCodigo_Proveedor(int Codigo_Proveedor) {
        this.Codigo_Proveedor = Codigo_Proveedor;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getEmpresa() {
        return Empresa;
    }

    public void setEmpresa(String Empresa) {
        this.Empresa = Empresa;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }
    
}
